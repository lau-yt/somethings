require 'test_helper'

class CommentReportAnswerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
