require 'test_helper'

class QuestionReportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
