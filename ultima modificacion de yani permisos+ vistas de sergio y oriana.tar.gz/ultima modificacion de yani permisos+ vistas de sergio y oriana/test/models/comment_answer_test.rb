require 'test_helper'

class CommentAnswerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
