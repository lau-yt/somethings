require 'test_helper'

class CommentQuestionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
