require 'test_helper'

class AnswerReportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
