require "application_system_test_case"

class CommentQuestionsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit comment_questions_url
  #
  #   assert_selector "h1", text: "CommentQuestion"
  # end
end
