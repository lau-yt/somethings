require "application_system_test_case"

class CommentReportQuestionsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit comment_report_questions_url
  #
  #   assert_selector "h1", text: "CommentReportQuestion"
  # end
end
