require "application_system_test_case"

class AnswerReportsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit answer_reports_url
  #
  #   assert_selector "h1", text: "AnswerReport"
  # end
end
