require "application_system_test_case"

class QuestionReportsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit question_reports_url
  #
  #   assert_selector "h1", text: "QuestionReport"
  # end
end
