require "application_system_test_case"

class AnswersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit answers_url
  #
  #   assert_selector "h1", text: "Answer"
  # end
end
