require "application_system_test_case"

class CommentAnswersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit comment_answers_url
  #
  #   assert_selector "h1", text: "CommentAnswer"
  # end
end
