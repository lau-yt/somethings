require "application_system_test_case"

class CommentReportAnswersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit comment_report_answers_url
  #
  #   assert_selector "h1", text: "CommentReportAnswer"
  # end
end
