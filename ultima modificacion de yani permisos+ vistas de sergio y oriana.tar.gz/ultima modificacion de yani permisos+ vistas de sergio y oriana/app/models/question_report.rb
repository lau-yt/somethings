class QuestionReport < ApplicationRecord
	belongs_to :question 	
end
