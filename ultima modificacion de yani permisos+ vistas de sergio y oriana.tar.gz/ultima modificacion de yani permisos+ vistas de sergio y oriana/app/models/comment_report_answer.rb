class CommentReportAnswer < ApplicationRecord
	belongs_to :comment_answer 	
end
