class Help < ApplicationRecord
end
