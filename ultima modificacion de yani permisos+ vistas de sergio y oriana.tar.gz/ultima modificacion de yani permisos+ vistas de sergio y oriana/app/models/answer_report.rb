class AnswerReport < ApplicationRecord
	belongs_to :answer 	
end
