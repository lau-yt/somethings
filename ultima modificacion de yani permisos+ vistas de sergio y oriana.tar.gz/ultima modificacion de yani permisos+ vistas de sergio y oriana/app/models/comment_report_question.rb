class CommentReportQuestion < ApplicationRecord
	belongs_to :comment_question 	
end
