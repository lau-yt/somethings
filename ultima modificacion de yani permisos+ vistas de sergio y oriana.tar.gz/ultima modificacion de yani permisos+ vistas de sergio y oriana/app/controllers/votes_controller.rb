class VotesController < ApplicationController
end
